<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">pipeline_javaService</value>
  <value name="encodeutf8">true</value>
  <value name="body">VmFsdWVzRW11bGF0b3IucHV0KHBpcGVsaW5lLCAibmFtZSIsICJVc2VyMTA1Iik7DQpWYWx1ZXNF
bXVsYXRvci5wdXQocGlwZWxpbmUsICJ3ZWlnaHQiLCAiIikNClZhbHVlc0VtdWxhdG9yLnB1dChw
aXBlbGluZSwgImFnZSIsICIiKTs=</value>
</Values>
