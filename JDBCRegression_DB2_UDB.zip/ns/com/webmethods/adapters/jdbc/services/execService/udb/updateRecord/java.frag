<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">updateRecord</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUKSURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJz
b3IoKTsKQ29ubmVjdGlvbiBjb25uZWN0aW9uID0gKENvbm5lY3Rpb24pSURhdGFVdGlsLmdldChw
aXBlbGluZUN1cnNvciwiJGRiX3NlcnZpY2VfY29ubmVjdGlvbiIpOwpTdHJpbmcgc3FsID0gbmV3
IFN0cmluZygidXBkYXRlIFRhYmxlMUAjJF8gc2V0IEYxQCMkXz0nSG91c2UnIik7CnRyeQp7Cglj
b25uZWN0aW9uLmNyZWF0ZVN0YXRlbWVudCgpLmV4ZWN1dGUoc3FsKTsKfQpjYXRjaCAoU1FMRXhj
ZXB0aW9uIGUpCnsKCXRocm93IG5ldyBTZXJ2aWNlRXhjZXB0aW9uKGUpOwp9CnBpcGVsaW5lQ3Vy
c29yLmRlc3Ryb3koKTs=</value>
</Values>
