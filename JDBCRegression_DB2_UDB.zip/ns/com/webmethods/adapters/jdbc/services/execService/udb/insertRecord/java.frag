<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">insertRecord</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUKSURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJz
b3IoKTsKQ29ubmVjdGlvbiBjb25uZWN0aW9uID0gKENvbm5lY3Rpb24pSURhdGFVdGlsLmdldChw
aXBlbGluZUN1cnNvciwiJGRiX3NlcnZpY2VfY29ubmVjdGlvbiIpOwpTdHJpbmcgc3FsID0gbmV3
IFN0cmluZygiaW5zZXJ0IGludG8gVGFibGUxQCMkXyB2YWx1ZXMgKDEyLCdIb21lJykiKTsKdHJ5
CnsKCWNvbm5lY3Rpb24uY3JlYXRlU3RhdGVtZW50KCkuZXhlY3V0ZShzcWwpOwp9CmNhdGNoIChT
UUxFeGNlcHRpb24gZSkKewoJdGhyb3cgbmV3IFNlcnZpY2VFeGNlcHRpb24oZSk7Cn0KcGlwZWxp
bmVDdXJzb3IuZGVzdHJveSgpOw==</value>
</Values>
