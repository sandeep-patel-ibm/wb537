<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">SetupJava</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUKSURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJz
b3IoKTsKU3RyaW5nIGZpbGVOYW1lID0gSURhdGFVdGlsLmdldChwaXBlbGluZUN1cnNvciwiZmls
ZU5hbWUiKS50b1N0cmluZygpOwpGaWxlIGZpbGUgPSBuZXcgRmlsZSgidGVtcC50eHQiKTsKU3lz
dGVtLm91dC5wcmludGxuKGZpbGUuZ2V0QWJzb2x1dGVQYXRoKCkpOwovKnRyeQp7CglSdW50aW1l
LmdldFJ1bnRpbWUoKS5leGVjKGZpbGVOYW1lKTsKfQpjYXRjaChJT0V4Y2VwdGlvbiBlKQp7Cgll
LnByaW50U3RhY2tUcmFjZSgpOwp9Ki8KcGlwZWxpbmVDdXJzb3IuZGVzdHJveSgpOw==</value>
</Values>
