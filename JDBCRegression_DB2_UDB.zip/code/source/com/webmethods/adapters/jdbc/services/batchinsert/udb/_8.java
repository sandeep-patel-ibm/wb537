package com.webmethods.adapters.jdbc.services.batchinsert.udb;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
// --- <<IS-END-IMPORTS>> ---

public final class _8

{
	// ---( internal utility methods )---

	final static _8 _instance = new _8();

	static _8 _newInstance() { return new _8(); }

	static _8 _cast(Object o) { return (_8)o; }

	// ---( server methods )---




	public static final void populateInput (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(populateInput)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] record:1:required inputs
		// [o] - object:0:required BIGINT_COL
		// [o] - object:0:required BLOB_COL
		// [o] - field:0:required CHARACTER_COL
		// [o] - field:0:required CLOB_COL
		// [o] - object:0:required DATE_COL
		// [o] - object:0:required DECIMAL_COL
		// [o] - object:0:required DOUBLE_COL
		// [o] - object:0:required INTEGER_COL
		// [o] - field:0:required LONGVARCHAR_COL
		// [o] - object:0:required REAL_COL
		// [o] - object:0:required SMALLINT_COL
		// [o] - object:0:required TIME_COL
		// [o] - object:0:required TIMESTAMP_COL
		// [o] - field:0:required VARCHAR_COL
		// Initialize start
		int start = 1;
		IData [] T_row = new IData[10];
		for (int i = start; i <=10; i++)
		{	
			Object orow[][] = {{"BIGINT_COL", new Long(1)},{"BLOB_COL", new String("Blob Column Values").getBytes()},
				{"CHARACTER_COL", new String("Char")},{"CLOB_COL", new String("Clob Column Values")},
				{"DATE_COL", Date.valueOf("1947-08-15")},{"DECIMAL_COL", new BigDecimal("1.234")},
				{"DOUBLE_COL", new Double(1.23)},
				{"INTEGER_COL", new Integer(i)},{"LONGVARCHAR_COL", new String("Long Varchar")},
				{"REAL_COL", new Float(1.23)},{"SMALLINT_COL", new Short((short)1)},
				{"TIME_COL", Time.valueOf("12:30:30")},{"TIMESTAMP_COL", Timestamp.valueOf("1947-08-15 12:30:30.300")},
				{"VARCHAR_COL", new String("Varchar")}};
			T_row[i-start] = (IData)new Values(orow);
		}
		ValuesEmulator.put(pipeline,"inputs",T_row);
		// --- <<IS-END>> ---

                
	}
}

