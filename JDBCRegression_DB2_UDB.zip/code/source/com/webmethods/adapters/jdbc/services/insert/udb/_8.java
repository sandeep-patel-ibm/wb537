package com.webmethods.adapters.jdbc.services.insert.udb;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.Date;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Time;
// --- <<IS-END-IMPORTS>> ---

public final class _8

{
	// ---( internal utility methods )---

	final static _8 _instance = new _8();

	static _8 _newInstance() { return new _8(); }

	static _8 _cast(Object o) { return (_8)o; }

	// ---( server methods )---




	public static final void pipeline_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(pipeline_javaService)>> ---
		// @sigtype java 3.5
		// [o] field:0:required name
		// [o] field:0:required weight
		// [o] field:0:required age
		ValuesEmulator.put(pipeline, "name", "User105");
		ValuesEmulator.put(pipeline, "weight", "")
		ValuesEmulator.put(pipeline, "age", "");
		// --- <<IS-END>> ---

                
	}



	public static final void populateInput (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(populateInput)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required int
		// [o] object:0:required BIGINT_COL
		// [o] object:0:required BLOB_COL
		// [o] field:0:required CHARACTER_COL
		// [o] field:0:required CLOB_COL
		// [o] object:0:required DATE_COL
		// [o] object:0:required DECIMAL_COL
		// [o] object:0:required DOUBLE_COL
		// [o] object:0:required INTEGER_COL
		// [o] field:0:required LONGVARCHAR_COL
		// [o] object:0:required REAL_COL
		// [o] object:0:required SMALLINT_COL
		// [o] object:0:required TIME_COL
		// [o] object:0:required TIMESTAMP_COL
		// [o] field:0:required VARCHAR_COL
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String oint = IDataUtil.get(pipelineCursor,"int").toString();
		pipelineCursor.insertAfter("BIGINT_COL", new Long(1));
		pipelineCursor.insertAfter("BLOB_COL", new String("Blob Column Values").getBytes());
		pipelineCursor.insertAfter("CHARACTER_COL", new String("Char"));
		pipelineCursor.insertAfter("CLOB_COL", new String("Clob Column Values"));
		pipelineCursor.insertAfter("DATE_COL", Date.valueOf("1947-08-15"));
		pipelineCursor.insertAfter("DECIMAL_COL", new BigDecimal("1.234"));
		pipelineCursor.insertAfter("DOUBLE_COL", new Double(1.23));
		pipelineCursor.insertAfter("INTEGER_COL", new Integer(oint));
		pipelineCursor.insertAfter("LONGVARCHAR_COL", new String("Long Varchar"));
		pipelineCursor.insertAfter("REAL_COL", new Float(1.23));
		pipelineCursor.insertAfter("SMALLINT_COL", new Short((short)1));
		pipelineCursor.insertAfter("TIME_COL", Time.valueOf("12:30:30"));
		pipelineCursor.insertAfter("TIMESTAMP_COL", Timestamp.valueOf("1947-08-15 12:30:30"));
		pipelineCursor.insertAfter("VARCHAR_COL", null);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

