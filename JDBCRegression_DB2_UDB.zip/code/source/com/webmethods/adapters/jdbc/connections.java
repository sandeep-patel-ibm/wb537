package com.webmethods.adapters.jdbc;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class connections

{
	// ---( internal utility methods )---

	final static connections _instance = new connections();

	static connections _newInstance() { return new connections(); }

	static connections _cast(Object o) { return (connections)o; }

	// ---( server methods )---




	public static final void generateConnectionInput (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateConnectionInput)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		IData T_row;
		String connectionAlias = IDataUtil.get(pipelineCursor,"connectionAlias").toString();
		String packageName = IDataUtil.get(pipelineCursor,"packageName").toString();
		String adapterTypeName = IDataUtil.get(pipelineCursor,"adapterTypeName").toString();
		String connectionFactoryType = IDataUtil.get(pipelineCursor,"connectionFactoryType").toString();
		String transactionType = IDataUtil.get(pipelineCursor,"transactionType").toString();
		String datasourceClass = IDataUtil.get(pipelineCursor,"datasourceClass").toString();
		String serverName = IDataUtil.get(pipelineCursor,"serverName").toString();
		String user = IDataUtil.get(pipelineCursor,"user").toString();
		String password = IDataUtil.get(pipelineCursor,"password").toString();
		String databaseName = IDataUtil.get(pipelineCursor,"databaseName").toString();
		String portNumber = IDataUtil.get(pipelineCursor,"portNumber").toString();
		String networkProtocol = IDataUtil.get(pipelineCursor,"networkProtocol").toString();
		String otherProperties = IDataUtil.get(pipelineCursor,"otherProperties").toString();
		Object oDocument[][] = {{"transactionType", transactionType},
			{"datasourceClass", datasourceClass},
			{"serverName", serverName}, {"user", user},
			{"password", password},{"databaseName", databaseName},
			{"portNumber", portNumber},{"networkProtocol", networkProtocol},
			{"otherProperties", otherProperties}};
		T_row = (IData)new Values(oDocument);
		pipelineCursor.insertAfter("connectionAlias", connectionAlias);
		pipelineCursor.insertAfter("packageName", packageName);
		pipelineCursor.insertAfter("adapterTypeName", adapterTypeName);
		pipelineCursor.insertAfter("connectionFactoryType", connectionFactoryType);
		ValuesEmulator.put(pipeline,"connectionSettings",T_row);
		
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void new_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(new_javaService)>> ---
		// @sigtype java 3.5
		// --- <<IS-END>> ---

                
	}
}

